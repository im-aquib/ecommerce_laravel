<?php $__env->startSection('content'); ?>
<div class="card card-default">
    <div class="card-header">
    Edit Product
    </div>
    <div class="card-body">
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
       <ul class="list-group">
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="list-group-item text-danger">
          <?php echo e($error); ?>

         </li>            
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </ul>
     </div>
     <?php endif; ?>
     

    <form action="<?php echo e(route('products.update', ['id' => $product->id ])); ?>" method="post" enctype="multipart/form-data">
         <?php echo e(csrf_field()); ?>

         <?php echo e(method_field('PUT')); ?>

            <div class="form-group">
                <label for="name">Name</label>
            <input type="text" id="name" class="form-control" name="name" value="<?php echo e($product->name); ?>">
            </div>

            <div class="form-group">
                <label for="price">Price</label>
            <input type="number" id="price" class="form-control" name="price" value="<?php echo e($product->price); ?>">
            </div>

            <div class="form-group">
                <label for="description">Description</label>
                <input id="description" value="<?php echo e($product->description); ?>" type="hidden" name="description">
                <trix-editor input="description"><?php echo $product->description; ?></trix-editor>
            </div>

            <div class="form-group">
                <label for="image">Image</label>
                <input type="file" id="image" class="form-control" name="Image" value="<?php echo e($product->image); ?>">
            </div>

            <div class="form-group">
                <label for="category">Category</label>
                <select name="category_id" id="category" class="form-control">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category->id); ?>"
                <?php if($category->id == $product->category->id): ?>
                   selected 
                <?php endif; ?>
                >
                <?php echo e($category->name); ?>

                </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>


            <div class="form-group">
                <button class="form-control btn btn-success">Update Product</button>
            </div>
        </form>
    </div>
</div>
    
<?php $__env->stopSection(); ?>


<?php $__env->startSection('styles'); ?>

<link href="https://cdnjs.cloudflare.com/ajax/libs/trix/1.3.0/trix.min.css" rel="stylesheet">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/trix/1.3.0/trix.min.js"></script>

    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>